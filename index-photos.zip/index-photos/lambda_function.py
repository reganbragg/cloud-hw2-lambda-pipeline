import base64
import json
import requests
import time
import urllib.parse

import boto3
from opensearchpy import OpenSearch, RequestsHttpConnection, AWSV4SignerAuth


region = 'us-east-1'

# Set up clients
s3_client = boto3.client('s3', region)
rk_client = boto3.client('rekognition', region)

# Lambda invocation hook
def lambda_handler(event, context):

    # Get the object from the event, get the object and key
    bucket = event['Records'][0]['s3']['bucket']['name']
    key = event['Records'][0]['s3']['object']['key']

    img = s3_client.get_object(Bucket=bucket, Key=key)
    head_obj = s3_client.head_object(Bucket=bucket, Key=key)
    
    # Array to hold new labels
    img_labels = []
    
    # Try getting the custom label from the metadata
    headers = head_obj['ResponseMetadata']['HTTPHeaders']

    if 'x-amz-meta-customlabels' in list(headers.keys()):
        customlabels = str(headers['x-amz-meta-customlabels'])
        for label in customlabels.split(','):
            img_labels.append(label.strip())

    data = img['Body'].read().decode('utf-8')
    decoded_image = base64.b64decode(data)
    response = rk_client.detect_labels(Image={'Bytes':decoded_image}, MaxLabels=10, MinConfidence = 85)
    rekognition_labels = response['Labels']
    
    # Add each of the labels from rekognition to the image labels
    for label in rekognition_labels:
        img_labels.append(label['Name'])
    
    time_stamp = time.strftime("%Y-%m-%dT%H:%M:%S", time.gmtime())
    
    json_obj = {"objectKey": key,
                "bucket": bucket,
                "createdTimestamp": time_stamp,
                "labels": img_labels}
                
    print(json.dumps(json_obj))
    # Send to opensearch
    credentials = boto3.Session().get_credentials()
    aws_auth = AWSV4SignerAuth(credentials, region)
    
    host = 'search-photos-ejddem6y36qhsxbezb6idfusbu.us-east-1.es.amazonaws.com'
    index = 'photos'

    opensearch_client = OpenSearch(
        hosts = [{"host": host, "port": 443}],
        http_auth = aws_auth,
        use_ssl = True,
        verify_certs=True,
        connection_class=RequestsHttpConnection)
        
    response = opensearch_client.index(index=index, body=json.dumps(json_obj), refresh=True)
    print(response)
    
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from index-photos')
    }
